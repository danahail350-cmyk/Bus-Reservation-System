public class Bus {
    // Concept 7: Encapsulation
    private String busNumber;
    private int totalSeats;
    // Concept 14: Multidimensional arrays (2D Array for seat map)
    private boolean[][] seatMap;
    private int rows;
    private int cols;
    
    // Concept 2: Constructors
    public Bus(String busNumber, int rows, int cols) {
        // Concept 3: The Keyword this
        this.busNumber = busNumber;
        this.rows = rows;
        this.cols = cols;
        this.totalSeats = rows * cols;
        this.seatMap = new boolean[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                seatMap[i][j] = false;
            }
        }
    }
    
    public String getBusNumber() {
        return busNumber;
    }
    
    public int getTotalSeats() {
        return totalSeats;
    }
    
    public int getRows() {
        return rows;
    }
    
    public int getCols() {
        return cols;
    }
    
    // Concept 12: Arrays in classes and methods
    public boolean[][] getSeatMap() {
        return seatMap;
    }
    
    // Concept 15: Exception Handling
    public boolean bookSeat(int row, int col) {
        try {
            if (row >= 0 && row < rows && col >= 0 && col < cols) {
                if (!seatMap[row][col]) {
                    seatMap[row][col] = true;
                    return true;
                } else {
                    System.out.println("Seat already booked!");
                    return false;
                }
            } else {
                System.out.println("Invalid seat position!");
                return false;
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Invalid seat selection - " + e.getMessage());
            return false;
        }
    }
    
    public int getAvailableSeats() {
        int available = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (!seatMap[i][j]) {
                    available++;
                }
            }
        }
        return available;
    }
    
    public void displaySeatMap() {
        System.out.println("\n=== Seat Map for Bus " + busNumber + " ===");
        System.out.print("   ");
        for (int j = 0; j < cols; j++) {
            System.out.print(" " + (j + 1) + " ");
        }
        System.out.println();
        
        for (int i = 0; i < rows; i++) {
            System.out.print((char)('A' + i) + "  ");
            for (int j = 0; j < cols; j++) {
                if (seatMap[i][j]) {
                    System.out.print("[X]");
                } else {
                    System.out.print("[ ]");
                }
            }
            System.out.println();
        }
        System.out.println("\nAvailable Seats: " + getAvailableSeats() + "/" + totalSeats);
        System.out.println("[ ] = Available  [X] = Booked\n");
    }
}
