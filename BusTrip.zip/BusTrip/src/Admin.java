// Concept 17: Inheritance (Subclass extends Superclass)
// Concept 20: Polymorphism
public class Admin extends User {
    private String adminLevel;
    
    // Concept 9: Overloading (Constructor overloading)
    public Admin(String username, String password) {
        super(username, password, "Admin");
        // Concept 3: The Keyword this
        this.adminLevel = "Standard";
    }
    
    public Admin(String username, String password, String adminLevel) {
        super(username, password, "Admin");
        this.adminLevel = adminLevel;
    }
    
    public String getAdminLevel() {
        return adminLevel;
    }
    
    public void setAdminLevel(String adminLevel) {
        this.adminLevel = adminLevel;
    }
    
    @Override
    public void displayInfo() {
        System.out.println("=================================");
        System.out.println("Admin Information:");
        System.out.println("Username: " + getUsername());
        System.out.println("Role: " + getRole());
        System.out.println("Admin Level: " + adminLevel);
        System.out.println("=================================");
    }
    
    // Concept 9: Overloading (Method overloading)
    public void displayInfo(boolean detailed) {
        if (detailed) {
            displayInfo();
            System.out.println("Additional Details: Full Access Privileges");
        } else {
            System.out.println("Admin: " + getUsername());
        }
    }
}
