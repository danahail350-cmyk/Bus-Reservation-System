import java.io.*;
import java.util.ArrayList;

public class BookingManager {
    // Concept 11: Creating and accessing ArrayList
    // Concept 16: Java Collection (ArrayList)
    private ArrayList<Trip> trips;
    private String filename = "trips_data.txt";
    
    public BookingManager() {
        this.trips = new ArrayList<Trip>();
        loadTripsFromFile();
    }
    
    // Concept 5: Using Objects as Parameters
    public void addTrip(Trip trip) {
        // Concept 4: The Keyword null
        if (trip != null) {
            trips.add(trip);
            System.out.println("Trip added successfully!");
        } else {
            System.out.println("Error: Cannot add null trip.");
        }
    }
    
    public ArrayList<Trip> getAllTrips() {
        return trips;
    }
    
    // Concept 13: Sorting arrays (Bubble Sort Algorithm)
    public void sortTripsByDestination() {
        int n = trips.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (trips.get(j).getDestination().compareTo(trips.get(j + 1).getDestination()) > 0) {
                    Trip temp = trips.get(j);
                    trips.set(j, trips.get(j + 1));
                    trips.set(j + 1, temp);
                }
            }
        }
        System.out.println("Trips sorted by destination!");
    }
    
    // Concept 13: Searching arrays
    public Trip searchTripById(int tripId) {
        for (Trip trip : trips) {
            if (trip.getTripId() == tripId) {
                return trip;
            }
        }
        return null;
    }
    
    // Concept 19: Recursion
    public Trip recursiveSearchByDestination(String destination, int index) {
        if (index >= trips.size()) {
            return null;
        }
        if (trips.get(index).getDestination().equalsIgnoreCase(destination)) {
            return trips.get(index);
        }
        return recursiveSearchByDestination(destination, index + 1);
    }
    
    public Trip searchTripByDestination(String destination) {
        return recursiveSearchByDestination(destination, 0);
    }
    
    public void displayAllTrips() {
        if (trips.isEmpty()) {
            System.out.println("No trips available.");
            return;
        }
        System.out.println("\n========== ALL TRIPS ==========");
        for (Trip trip : trips) {
            trip.displayTripDetails();
        }
    }
    
    // Concept 18: Text-file input and output
    // Concept 15: Exception Handling
    public void saveTripsToFile() {
        try {
            FileWriter writer = new FileWriter(filename);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
            
            for (Trip trip : trips) {
                bufferedWriter.write(trip.toFileString());
                bufferedWriter.newLine();
            }
            
            bufferedWriter.close();
            System.out.println("Trips saved to file successfully!");
            
        } catch (IOException e) {
            System.out.println("Error saving to file: " + e.getMessage());
        }
    }
    
    public void loadTripsFromFile() {
        try {
            File file = new File(filename);
            if (!file.exists()) {
                System.out.println("No previous data found. Starting fresh.");
                return;
            }
            
            FileReader reader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(reader);
            
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                try {
                    String[] parts = line.split(",");
                    int tripId = Integer.parseInt(parts[0]);
                    String destination = parts[1];
                    String date = parts[2];
                    double basePrice = Double.parseDouble(parts[3]);
                    TripType tripType = TripType.valueOf(parts[4]);
                    String busNumber = parts[5];
                    
                    Bus bus = new Bus(busNumber, 8, 4);
                    Trip trip = new Trip(tripId, destination, date, basePrice, tripType, bus);
                    trips.add(trip);
                    
                } catch (Exception e) {
                    System.out.println("Error parsing line: " + line);
                }
            }
            
            bufferedReader.close();
            System.out.println("Trips loaded from file successfully! Total: " + trips.size());
            
        } catch (FileNotFoundException e) {
            System.out.println("File not found. Starting with empty trip list.");
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
    }
    
    // Concept 19: Recursion
    public void recursiveDisplayTrips(int index) {
        if (index >= trips.size()) {
            return;
        }
        trips.get(index).displayTripDetails();
        recursiveDisplayTrips(index + 1);
    }
    
    // Concept 8: Methods Calling Methods
    public void displayAllTripsRecursively() {
        if (trips.isEmpty()) {
            System.out.println("No trips available.");
            return;
        }
        System.out.println("\n========== ALL TRIPS (Recursive Display) ==========");
        recursiveDisplayTrips(0);
    }
}
