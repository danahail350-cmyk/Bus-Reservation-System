import java.util.Scanner;

public class BusSystemMain {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BookingManager bookingManager = new BookingManager();
        
        // Concept 20: Polymorphism (User reference to Admin object)
        User admin = new Admin("admin", "admin123", "Super");
        
        System.out.println("╔════════════════════════════════════════╗");
        System.out.println("║   BUS RESERVATION SYSTEM - LOGIN       ║");
        System.out.println("╔════════════════════════════════════════╗");
        
        boolean loggedIn = false;
        int loginAttempts = 0;
        
        // Concept 15: Exception Handling
        while (!loggedIn && loginAttempts < 3) {
            try {
                System.out.print("\nEnter Username: ");
                String username = scanner.nextLine();
                System.out.print("Enter Password: ");
                String password = scanner.nextLine();
                
                if (admin.authenticate(username, password)) {
                    loggedIn = true;
                    System.out.println("\n✓ Login Successful! Welcome, " + admin.getUsername());
                    admin.displayInfo();
                } else {
                    loginAttempts++;
                    System.out.println("✗ Invalid credentials! Attempts remaining: " + (3 - loginAttempts));
                }
            } catch (Exception e) {
                System.out.println("Error during login: " + e.getMessage());
                loginAttempts++;
            }
        }
        
        if (!loggedIn) {
            System.out.println("\nToo many failed attempts. System locked.");
            scanner.close();
            return;
        }
        
        boolean running = true;
        
        while (running) {
            try {
                System.out.println("\n╔════════════════════════════════════════╗");
                System.out.println("║      BUS RESERVATION SYSTEM MENU       ║");
                System.out.println("╠════════════════════════════════════════╣");
                System.out.println("║  1. Add New Trip                       ║");
                System.out.println("║  2. Book a Ticket                      ║");
                System.out.println("║  3. Search Trip by ID                  ║");
                System.out.println("║  4. Search Trip by Destination         ║");
                System.out.println("║  5. Display All Trips (Sorted)         ║");
                System.out.println("║  6. View Bus Seating                   ║");
                System.out.println("║  7. Display Trips (Recursive)          ║");
                System.out.println("║  8. Save & Exit                        ║");
                System.out.println("╚════════════════════════════════════════╝");
                System.out.print("Enter your choice (1-8): ");
                
                int choice;
                try {
                    choice = Integer.parseInt(scanner.nextLine());
                } catch (NumberFormatException e) {
                    System.out.println("✗ Invalid input! Please enter a number between 1-8.");
                    continue;
                }
                
                switch (choice) {
                    case 1:
                        addNewTrip(scanner, bookingManager);
                        break;
                    case 2:
                        bookTicket(scanner, bookingManager);
                        break;
                    case 3:
                        searchTripById(scanner, bookingManager);
                        break;
                    case 4:
                        searchTripByDestination(scanner, bookingManager);
                        break;
                    case 5:
                        displayAllTripsSorted(bookingManager);
                        break;
                    case 6:
                        viewBusSeating(scanner, bookingManager);
                        break;
                    case 7:
                        bookingManager.displayAllTripsRecursively();
                        break;
                    case 8:
                        bookingManager.saveTripsToFile();
                        System.out.println("\n✓ Data saved! Thank you for using Bus Reservation System.");
                        running = false;
                        break;
                    default:
                        System.out.println("✗ Invalid choice! Please enter a number between 1-8.");
                }
                
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                System.out.println("Please try again.");
            }
        }
        
        scanner.close();
    }
    
    // Concept 1: Methods
    private static void addNewTrip(Scanner scanner, BookingManager bookingManager) {
        System.out.println("\n=== ADD NEW TRIP ===");
        
        try {
            System.out.print("Enter Trip ID: ");
            int tripId = Integer.parseInt(scanner.nextLine());
            
            System.out.print("Enter Destination: ");
            String destination = scanner.nextLine();
            
            System.out.print("Enter Date (DD/MM/YYYY): ");
            String date = scanner.nextLine();
            
            System.out.print("Enter Base Price: $");
            double basePrice = Double.parseDouble(scanner.nextLine());
            
            // Concept 10: Enumeration
            System.out.println("\nSelect Trip Type:");
            System.out.println("1. EXPRESS - " + TripType.EXPRESS.getDescription());
            System.out.println("2. LOCAL - " + TripType.LOCAL.getDescription());
            System.out.println("3. LUXURY - " + TripType.LUXURY.getDescription());
            System.out.print("Enter choice (1-3): ");
            int typeChoice = Integer.parseInt(scanner.nextLine());
            
            TripType tripType;
            switch (typeChoice) {
                case 1:
                    tripType = TripType.EXPRESS;
                    break;
                case 2:
                    tripType = TripType.LOCAL;
                    break;
                case 3:
                    tripType = TripType.LUXURY;
                    break;
                default:
                    tripType = TripType.LOCAL;
                    System.out.println("Invalid choice. Using LOCAL by default.");
            }
            
            System.out.print("Enter Bus Number: ");
            String busNumber = scanner.nextLine();
            
            System.out.print("Enter Number of Rows: ");
            int rows = Integer.parseInt(scanner.nextLine());
            
            System.out.print("Enter Number of Columns: ");
            int cols = Integer.parseInt(scanner.nextLine());
            
            // Concept 14: Multidimensional arrays (inside Bus constructor)
            Bus bus = new Bus(busNumber, rows, cols);
            Trip trip = new Trip(tripId, destination, date, basePrice, tripType, bus);
            
            bookingManager.addTrip(trip);
            
        } catch (NumberFormatException e) {
            System.out.println("✗ Error: Invalid number format - " + e.getMessage());
        } catch (Exception e) {
            System.out.println("✗ Error adding trip: " + e.getMessage());
        }
    }
    
    private static void bookTicket(Scanner scanner, BookingManager bookingManager) {
        System.out.println("\n=== BOOK A TICKET ===");
        
        try {
            System.out.print("Enter Trip ID: ");
            int tripId = Integer.parseInt(scanner.nextLine());
            
            Trip trip = bookingManager.searchTripById(tripId);
            
            // Concept 4: The Keyword null
            if (trip == null) {
                System.out.println("✗ Trip not found!");
                return;
            }
            
            trip.displayTripDetails();
            trip.getBus().displaySeatMap();
            
            System.out.print("\nEnter Row (A, B, C...): ");
            String rowInput = scanner.nextLine().toUpperCase();
            int row = rowInput.charAt(0) - 'A';
            
            System.out.print("Enter Column (1, 2, 3...): ");
            int col = Integer.parseInt(scanner.nextLine()) - 1;
            
            if (trip.bookTicket(row, col)) {
                System.out.println("✓ Ticket booked successfully!");
                System.out.println("Seat: " + rowInput + (col + 1));
                System.out.println("Final Price: $" + trip.calculateFinalPrice());
            } else {
                System.out.println("✗ Booking failed!");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("✗ Error: Invalid input format - " + e.getMessage());
        } catch (Exception e) {
            System.out.println("✗ Error booking ticket: " + e.getMessage());
        }
    }
    
    // Concept 13: Searching arrays
    private static void searchTripById(Scanner scanner, BookingManager bookingManager) {
        System.out.println("\n=== SEARCH TRIP BY ID ===");
        
        try {
            System.out.print("Enter Trip ID: ");
            int tripId = Integer.parseInt(scanner.nextLine());
            
            Trip trip = bookingManager.searchTripById(tripId);
            
            if (trip != null) {
                trip.displayTripDetails();
            } else {
                System.out.println("✗ Trip not found!");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("✗ Error: Invalid number format - " + e.getMessage());
        }
    }
    
    // Concept 19: Recursion (uses recursive search)
    private static void searchTripByDestination(Scanner scanner, BookingManager bookingManager) {
        System.out.println("\n=== SEARCH TRIP BY DESTINATION (Recursive) ===");
        
        System.out.print("Enter Destination: ");
        String destination = scanner.nextLine();
        
        Trip trip = bookingManager.searchTripByDestination(destination);
        
        if (trip != null) {
            System.out.println("✓ Trip found!");
            trip.displayTripDetails();
        } else {
            System.out.println("✗ No trip found to " + destination);
        }
    }
    
    // Concept 13: Sorting arrays
    private static void displayAllTripsSorted(BookingManager bookingManager) {
        bookingManager.sortTripsByDestination();
        bookingManager.displayAllTrips();
    }
    
    private static void viewBusSeating(Scanner scanner, BookingManager bookingManager) {
        System.out.println("\n=== VIEW BUS SEATING ===");
        
        try {
            System.out.print("Enter Trip ID: ");
            int tripId = Integer.parseInt(scanner.nextLine());
            
            Trip trip = bookingManager.searchTripById(tripId);
            
            if (trip != null) {
                trip.getBus().displaySeatMap();
            } else {
                System.out.println("✗ Trip not found!");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("✗ Error: Invalid number format - " + e.getMessage());
        }
    }
}
