// Concept 1: Classes, Objects, Fields, Methods
// Concept 17: Inheritance (Superclass)
public abstract class User {
    // Concept 7: Private Modifiers (Encapsulation)
    private String username;
    private String password;
    private String role;
    
    // Concept 2: Constructors
    // Concept 6: Methods With Parameters of Primitive Types
    public User(String username, String password, String role) {
        // Concept 3: The Keyword this
        this.username = username;
        this.password = password;
        this.role = role;
    }
    
    // Concept 7: Encapsulation - Getters and Setters
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
    
    public abstract void displayInfo();
    
    // Concept 8: Methods Calling Methods
    public boolean authenticate(String inputUsername, String inputPassword) {
        return checkCredentials(inputUsername, inputPassword);
    }
    
    private boolean checkCredentials(String inputUsername, String inputPassword) {
        return this.username.equals(inputUsername) && this.password.equals(inputPassword);
    }
}
