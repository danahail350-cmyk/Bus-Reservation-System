// Concept 10: Enumeration as a class
enum TripType {
    EXPRESS("Express Service", 1.5),
    LOCAL("Local Service", 1.0),
    LUXURY("Luxury Service", 2.0);
    
    private final String description;
    private final double priceMultiplier;
    
    TripType(String description, double priceMultiplier) {
        this.description = description;
        this.priceMultiplier = priceMultiplier;
    }
    
    public String getDescription() {
        return description;
    }
    
    public double getPriceMultiplier() {
        return priceMultiplier;
    }
}

public class Trip {
    // Concept 7: Encapsulation
    private int tripId;
    private String destination;
    private String date;
    private double basePrice;
    private TripType tripType;
    // Concept 20: Aggregation (Trip HAS-A Bus)
    private Bus bus;
    
    // Concept 2: Constructors
    // Concept 6: Methods With Parameters of Primitive Types
    public Trip(int tripId, String destination, String date, double basePrice, TripType tripType, Bus bus) {
        // Concept 3: The Keyword this
        this.tripId = tripId;
        this.destination = destination;
        this.date = date;
        this.basePrice = basePrice;
        this.tripType = tripType;
        this.bus = bus;
    }
    
    public int getTripId() {
        return tripId;
    }
    
    public void setTripId(int tripId) {
        this.tripId = tripId;
    }
    
    public String getDestination() {
        return destination;
    }
    
    public void setDestination(String destination) {
        this.destination = destination;
    }
    
    public String getDate() {
        return date;
    }
    
    public void setDate(String date) {
        this.date = date;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
    
    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }
    
    public TripType getTripType() {
        return tripType;
    }
    
    public void setTripType(TripType tripType) {
        this.tripType = tripType;
    }
    
    // Concept 5: Using Objects as Parameters
    public Bus getBus() {
        return bus;
    }
    
    public void setBus(Bus bus) {
        this.bus = bus;
    }
    
    public double calculateFinalPrice() {
        return basePrice * tripType.getPriceMultiplier();
    }
    
    // Concept 8: Methods Calling Methods
    public void displayTripDetails() {
        System.out.println("=================================");
        System.out.println("Trip ID: " + tripId);
        System.out.println("Destination: " + destination);
        System.out.println("Date: " + date);
        System.out.println("Trip Type: " + tripType.getDescription());
        System.out.println("Base Price: $" + basePrice);
        System.out.println("Final Price: $" + calculateFinalPrice());
        System.out.println("Bus Number: " + bus.getBusNumber());
        System.out.println("Available Seats: " + bus.getAvailableSeats() + "/" + bus.getTotalSeats());
        System.out.println("=================================");
    }
    
    public boolean bookTicket(int row, int col) {
        return bus.bookSeat(row, col);
    }
    
    public String toFileString() {
        return tripId + "," + destination + "," + date + "," + basePrice + "," + tripType.name() + "," + bus.getBusNumber();
    }
}
